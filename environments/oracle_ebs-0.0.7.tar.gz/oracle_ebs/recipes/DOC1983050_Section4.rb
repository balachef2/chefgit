log '
     **********************************************
     *                                            *
     *        EBS Recipe:DOC1983050_Section4      *
     *                                            *
     **********************************************
    '

log '
     #-----------------------------------------#
     # Doc_ID_1983050.1_Section4 is Upgrading  #
     # the database with Opatches.  Patch      #
     # numbers came from Doc_ID: 1594274.1     #
     #-----------------------------------------#
    '


log '
     #-----------------------------------------#
     # Doc_ID_1983050.1_Section4 is superceded #
     #  by the upgrade to 11.2.0.4 procedure,  #
     #  which is in Doc_id: 1623879.1 Section  #
     #  6, which is in dbms_upgrade4.rb        #
     #-----------------------------------------#
    '

